﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Price
{
    public class Price : IComparable
    {
        private string _shopName;
        private string _productName { get; set; }
        private decimal _priceRub { get; set; }
        private bool _rreapet { get; set; }

        public bool rreapet { get; set; }
        public string shopName 
        {
            get { return _shopName; }
            set {rreapet=true; CheckTo(value); _shopName = value; }
                
        }
        public string productName 
        {
            get { return _productName; }
            set { rreapet = true; CheckTo(value); _productName = value;  } 
        }
        //public decimal priceRub 
        //{ 
        //    get { return _priceRub; }
        //    set {
        //        _priceRub = value;
        //    }
        //}
        public decimal priceRub { get { return _priceRub; } set { rreapet = true;_priceRub = value; } }

        public Price()
        {

        }
        public Price(string shopName, string productName, decimal priceRub)
        {
            _shopName = shopName;
            _productName = productName;
            _priceRub = priceRub;
        }
        public override string ToString()
        {
            return $"Название магазина: {shopName}\n Название товара: {productName}\n цена в рублях:{priceRub}";
        }

        public int CompareTo(object? other)
        {
            if (other is Price price) return shopName.CompareTo(price.shopName);
            else throw new ArgumentException("Бездарь");
        }
        public string CheckTo(string value)
        {
            if (String.IsNullOrEmpty(value))
            {
                Console.WriteLine("нкеорекктные данные");
                rreapet = false;
                return null;
            }
            else
            {
               
                return value;
                
            }
        }

        //public decimal CCheckTo(decimal value)
        //{
        //    if(decimal.TryParse(Console.ReadLine(), out value))
        //    {
        //        return value;
        //    }
        //    else
        //    {
        //        Console.WriteLine("некорекккктные даннные");
        //        return 0;
        //    }
        //}
    }
}
