﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Price
{
    class Program
    {
        static void Main(string[] args)
        {
            Price[] prices = new Price[3];
            bool repeat = true;
                while (repeat == true)
                {


                    for (int i = 0; i < prices.Length; i++)
                    {

                        prices[i] = new Price();
                        Console.Write("Введите название магазина: ");
                        prices[i].shopName = Console.ReadLine();
                        if (prices[i].rreapet == false)
                        {
                            break;
                        }
                        Console.Write("Введите название товара: ");
                        prices[i].productName = Console.ReadLine();
                        if (prices[i].rreapet == false)
                        {
                            break;
                        }
                        Console.Write("Введите стоимость товара: ");
                        decimal result;
                        if (decimal.TryParse(Console.ReadLine(), out result))
                        {
                            prices[i].priceRub = result;
                        }
                        else
                        {
                            Console.WriteLine("бездарь");
                        break;
                        }
                        if (prices[i].rreapet == false)
                        {
                        break;
                        }
                        repeat=false;
                    }
                }
            Array.Sort(prices);
            for (int i = 0; i < prices.Length; i++)
            {
                Console.WriteLine(prices[i]);
            }
            
            Console.WriteLine("Введите название магазина для вывода товаров");
            string nameShop = Console.ReadLine();
            bool massage = false;
            for (int i = 0; i<prices.Length; i++)
            {
                if(prices[i].shopName == nameShop)
                {
                    Console.WriteLine($"Название товара: {prices[i].productName} Цена: {prices[i].priceRub}руб.");
                    massage = true;
                    break;
                }
               
            }
            if (massage == false)
            {
                Console.WriteLine("Такого магазина нет в списках");
            }


        }
    }
}