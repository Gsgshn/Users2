﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Note
{
    public class Note
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int DateBirth { get; set; }
        public int MonthBirth { get; set; }
        public int YearBirth { get; set; }
        public int PhoneNumber { get; set; }
        public Note()
        {

        }
        public Note(string firstName, string lastName, int dateBirth, int monthBirth, int yearBirth, int phoneNumber)
        {
            FirstName = firstName;
            LastName = lastName;
            DateBirth = dateBirth;
            MonthBirth = monthBirth;
            YearBirth = yearBirth;
            PhoneNumber = phoneNumber;
        }
        public override string ToString()
        {
            return $"Имя: {FirstName}\nФамилия: {LastName}\nМобила ксяоми: {PhoneNumber} \nДр: {DateBirth}:{MonthBirth}:{YearBirth}";
        }


        //public static Note CreateNote()
        //{
        //    //
        //    return new Note();

        //    //


        //    //bool repeat = true;
        //    //Note[] notes = new Note[3];
        //    //while (repeat == true)
        //    //{

        //    //    

        //    //}
        //}
        //public void FillingNote(ref Note notes)
        //{
        //    bool repeat = true;
        //    while (repeat == true)
        //    {

        //        for (int i = 0; i < notes.Length; i++)
        //        {
        //            notes[i] = new Note();

        //            Console.Write("Введите имя:");

        //            notes[i].FirstName = Console.ReadLine();
        //            if (notes[i].FirstName == string.Empty)
        //            {
        //                Console.WriteLine("Некоректные данные");
        //                break;

        //            }

        //            Console.Write("Введите фамилию:");
        //            notes[i].LastName = Console.ReadLine();
        //            if (notes[i].LastName == string.Empty)
        //            {
        //                Console.WriteLine("Некоректные данные");
        //                break;
        //            }

        //            Console.Write($"Введите номер телефона:");


        //            int result;
        //            if (int.TryParse(Console.ReadLine(), out result))
        //            {
        //                notes[i].PhoneNumber = result;
        //            }
        //            else
        //            {
        //                Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
        //                break;
        //            }

        //            Console.WriteLine("Введите дату рождения в след виде: день рождения<Enter>,месяц рождения<Enter>,год рождения<Enter>");

        //            if (int.TryParse(Console.ReadLine(), out result))
        //            {
        //                notes[i].DateBirth = result;
        //            }
        //            else
        //            {
        //                Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
        //                break;
        //            }


        //            if (int.TryParse(Console.ReadLine(), out result))
        //            {
        //                notes[i].MonthBirth = result;
        //            }
        //            else
        //            {
        //                Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
        //                break;
        //            }

        //            if (int.TryParse(Console.ReadLine(), out result))
        //            {
        //                notes[i].YearBirth = result;
        //            }
        //            else
        //            {
        //                Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
        //                break;
        //            }

        //            repeat = false;
        //        }

        //    }
        //}


        //public void SortNote(ref Note[] notes)
        //{


        //    Console.WriteLine("Студосы:");
        //    for (int i = 0; i < notes.Length; i++)
        //    {
        //        for (int j = 0; j < notes.Length; j++)
        //        {
        //            if (notes[i].YearBirth == notes[j].YearBirth)
        //            {
        //                if (notes[i].MonthBirth == notes[j].MonthBirth)
        //                {
        //                    if (notes[i].DateBirth == notes[j].DateBirth)
        //                    {
        //                        Note temp;

        //                        temp = notes[i];
        //                        notes[i] = notes[j];
        //                        notes[j] = temp;
        //                    }
        //                    else
        //                    {
        //                        if (notes[i].DateBirth < notes[j].DateBirth)
        //                        {
        //                            Note temp;

        //                            temp = notes[i];
        //                            notes[i] = notes[j];
        //                            notes[j] = temp;
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    if (notes[i].MonthBirth < notes[j].MonthBirth)
        //                    {
        //                        Note temp;

        //                        temp = notes[i];
        //                        notes[i] = notes[j];
        //                        notes[j] = temp;
        //                    }
        //                }


        //            }
        //            else
        //            {
        //                if (notes[i].YearBirth < notes[j].YearBirth)
        //                {
        //                    Note temp;

        //                    temp = notes[i];
        //                    notes[i] = notes[j];
        //                    notes[j] = temp;
        //                }
        //            }

        //        }
        //    }
        //}


        //public void Search(ref Note[] notes)
        //{


        //    Console.WriteLine("Студосы:");
        //    Console.WriteLine("Выьерите студента по номеру телефона:");
        //    int number = Convert.ToInt32(Console.ReadLine());
        //    //for(int i = 0; i < notes.Length; i++) 
        //    //if (number != notes[i].PhoneNumber)
        //    //{
        //    //    Console.WriteLine("Такого номера нет");
        //    //}


        //    for (int i = 0; i < notes.Length; i++)
        //    {
        //        if (notes[i].PhoneNumber == number)
        //        {
        //            Console.WriteLine(notes[i]);
        //        }
        //        else
        //        {

        //        }
        //    }
        //}



        public void Mamba()
        {
            bool repeat = true;
            Note[] notes = new Note[3];
            while (repeat == true)
            {

                for (int i = 0; i < notes.Length; i++)
                {
                    notes[i] = new Note();

                    Console.Write("Введите имя:");

                    notes[i].FirstName = Console.ReadLine();
                    if (notes[i].FirstName == string.Empty)
                    {
                        Console.WriteLine("Некоректные данные");
                        break;

                    }

                    Console.Write("Введите фамилию:");
                    notes[i].LastName = Console.ReadLine();
                    if (notes[i].LastName == string.Empty)
                    {
                        Console.WriteLine("Некоректные данные");
                        break;
                    }

                    Console.Write($"Введите номер телефона:");


                    int result;
                    if (int.TryParse(Console.ReadLine(), out result))
                    {
                        notes[i].PhoneNumber = result;
                    }
                    else
                    {
                        Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
                        break;
                    }

                    Console.WriteLine("Введите дату рождения в след виде: день рождения<Enter>,месяц рождения<Enter>,год рождения<Enter>");

                    if (int.TryParse(Console.ReadLine(), out result))
                    {
                        notes[i].DateBirth = result;
                    }
                    else
                    {
                        Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
                        break;
                    }


                    if (int.TryParse(Console.ReadLine(), out result))
                    {
                        notes[i].MonthBirth = result;
                    }
                    else
                    {
                        Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
                        break;
                    }

                    if (int.TryParse(Console.ReadLine(), out result))
                    {
                        notes[i].YearBirth = result;
                    }
                    else
                    {
                        Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
                        break;
                    }

                    repeat = false;
                }
            }
            Console.WriteLine("Студосы:");
            for (int i = 0; i < notes.Length; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (notes[i].YearBirth == notes[j].YearBirth)
                    {
                        if (notes[i].MonthBirth == notes[j].MonthBirth)
                        {
                            if (notes[i].DateBirth == notes[j].DateBirth)
                            {
                                Note temp;

                                temp = notes[i];
                                notes[i] = notes[j];
                                notes[j] = temp;
                            }
                            else
                            {
                                if (notes[i].DateBirth < notes[j].DateBirth)
                                {
                                    Note temp;

                                    temp = notes[i];
                                    notes[i] = notes[j];
                                    notes[j] = temp;
                                }
                            }
                        }
                        else
                        {
                            if (notes[i].MonthBirth < notes[j].MonthBirth)
                            {
                                Note temp;

                                temp = notes[i];
                                notes[i] = notes[j];
                                notes[j] = temp;
                            }
                        }


                    }
                    else
                    {
                        if (notes[i].YearBirth < notes[j].YearBirth)
                        {
                            Note temp;

                            temp = notes[i];
                            notes[i] = notes[j];
                            notes[j] = temp;
                        }
                    }

                }
            }
            for (int i = 0; i < notes.Length; i++)
            {
                Console.WriteLine(notes[i]);
            }
            Console.WriteLine("Выьерите студента по номеру телефона:");
            int number = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < notes.Length; i++)
                if (number != notes[i].PhoneNumber)
                {
                    Console.WriteLine("Такого номера нет");
                }


            for (int i = 0; i < notes.Length; i++)
            {
                if (notes[i].PhoneNumber == number)
                {
                    Console.WriteLine(notes[i]);
                }
                else
                {

                }
            }

        }
    }
}

