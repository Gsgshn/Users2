﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Note
{
    class Program
    {
        static void Main(string[] args)
        {
            //Note[] notes = new Note[3];
            Note noteee = new Note();
            noteee.Mamba();
            //for (int i = 0; i < 3; i++)
            //{
            //    notes[i] = Note.CreateNote();
            //}

        }
    }
}