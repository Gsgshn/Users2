﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Zodiac
{

    public class Program
    {
        static void Main(string[] args)
        {



            Zodiac[] mas = new Zodiac[3];
            for (int i = 0; i < mas.Length; i++)
            {
                mas[i] = new Zodiac();
                Console.Write("Введите имя: ");
                mas[i].firstName = Console.ReadLine();
                Console.Write("Введите фамилию: ");
                mas[i].secondName = Console.ReadLine();
                Console.Write("Введите знак зодиака: ");
                mas[i].zodiac = Console.ReadLine();
                Console.Write("Введите ДЕНЬ рождения: ");
                mas[i].birthD = int.Parse(Console.ReadLine());
                Console.Write("Введите МЕСЯЦ рождения: ");
                mas[i].birthM = int.Parse(Console.ReadLine());
                Console.Write("Введите ГОД рождения: ");
                mas[i].birthY = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < mas.Length; i++)
            {
                for (int j = 0; j < mas.Length - 1 - i; j++)
                {
                    if (mas[i].birthY > mas[j].birthY)
                    {
                        Zodiac temp = mas[i];
                        mas[i] = mas[j];
                        mas[j] = temp;
                    }
                }
            }
            Console.WriteLine("Информация о людях (отсортированная по дате рождения): ");
            for (int i = 0; i < mas.Length; i++)
            {
                Console.WriteLine(mas[i]);
            }

            Console.WriteLine("Введите фамилию человека: ");
            string flag = Console.ReadLine();
            bool massage = false;
            for (int i = 0; i < mas.Length; i++)
            {
                if (mas[i].secondName == flag)
                {
                    Console.WriteLine(mas[i]);
                    massage = true;
                    break;
                }


            }
            if (massage == false)
            {
                Console.WriteLine("Такого человека нет в списках");
            }


        }

    }
}