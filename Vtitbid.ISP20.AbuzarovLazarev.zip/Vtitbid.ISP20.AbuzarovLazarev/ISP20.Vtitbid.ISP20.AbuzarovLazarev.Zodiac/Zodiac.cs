﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Zodiac
{
    public class Zodiac
    {
        public string firstName { get; set; }
        public string secondName { get; set; }
        public string zodiac { get; set; }
        public int birthD { get; set; }
        public int birthM { get; set; }
        public int birthY { get; set; }

        public Zodiac() { }
        public Zodiac(string Firstname, string Secondname, string Zodiac, int BirthD, int BirthM, int BirthY)
        {
            this.firstName = Firstname;
            this.secondName = Secondname;
            this.zodiac = Zodiac;
            this.birthD = BirthD;
            this.birthM = BirthM;
            this.birthY = BirthY;
        }
        public override string ToString()
        {
            return (string.Format(@" 
            Имя: {0} 
            Фамилия: {1} 
            Знак зодиака: {2}
            Дата рождения: {3}.{4}.{5} ", firstName, secondName, zodiac, birthD, birthM, birthY));
        }
    }
}
