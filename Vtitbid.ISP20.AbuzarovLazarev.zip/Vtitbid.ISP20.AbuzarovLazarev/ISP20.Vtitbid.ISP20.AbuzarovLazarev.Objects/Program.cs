﻿namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Objects
{
    class Program
    {
        static void Main(string[] args)
        {
           
            bool repeat = true;
            Route[] routes = new Route[3];
            while (repeat == true)
            {


                for (int i = 0; i < routes.Length; i++)
                {
                    routes[i] = new Route();

                    Console.Write("Введите название начального пункта маршрута:");

                    routes[i].FirstPointRoute = Console.ReadLine();
                    if (routes[i].FirstPointRoute == string.Empty)
                    {
                        Console.WriteLine("Некоректные данные");
                        break;

                    }

                    Console.Write("Введите название конечного пункта маршрута:");
                    routes[i].EndPointRoute = Console.ReadLine();
                    if (routes[i].EndPointRoute == string.Empty)
                    {
                        Console.WriteLine("Некоректные данные");
                        break;
                    }

                    Console.Write($"Введите номер маршрута от 1 до {routes.Length} не повторяясь:") ;
                    
                        int result;
                    if (int.TryParse(Console.ReadLine(), out result))
                    {
                        routes[i].RouteNumber = result;
                    }
                    else



                    {
                        Console.WriteLine("Некоректные данные\nВведите все сначала!!!");
                        break;
                    }
                    
                    repeat = false;
                }
            }
            Console.WriteLine("Маршруты:");
            for(int i = 0; i < routes.Length; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    if (routes[i].RouteNumber < routes[j].RouteNumber)
                    {
                        Route temp;

                        temp = routes[i];
                        routes[i] = routes[j];
                        routes[j]=temp;
                    }
                   
                }
            }
            for (int i = 0; i < routes.Length; i++)
            {
                Console.WriteLine(routes[i]);
            }
            Console.WriteLine("Выберите номер маршрута:");
            int number = Convert.ToInt32(Console.ReadLine());
            if (number > routes.Length)
            {
                Console.WriteLine("Такого номера нет");
            }
            else
            {
                if (number < 1)
                {
                    Console.WriteLine("Такого номера нет");
                }
            }
            for (int i  = 0;i<routes.Length;i++)
            {
                if(routes[i].RouteNumber == number)
                {
                    Console.WriteLine(routes[i]);
                }
                else
                {
                    
                }
            }

        }
    }
}