﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISP20.Vtitbid.ISP20.AbuzarovLazarev.Objects
{
    public class Route
    {
        public string FirstPointRoute { get; set; }
        public string EndPointRoute { get; set; }
        public int RouteNumber { get; set; }

        public Route()
        {

        }

        public Route(string firstPointRoute, string endPointRoute, int routeNumber)
        {
            FirstPointRoute = firstPointRoute;
            EndPointRoute = endPointRoute;
            RouteNumber = routeNumber;
        }
        public override string ToString()
        {
            return (string.Format(@"
            Началка:{0}
            Мачалка:{1}
            Номер:{2}", FirstPointRoute, EndPointRoute, RouteNumber));
        }
    }
}
